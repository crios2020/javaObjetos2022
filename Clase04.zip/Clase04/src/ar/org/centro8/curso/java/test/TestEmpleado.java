package ar.org.centro8.curso.java.test;


import javax.swing.JOptionPane;

import ar.org.centro8.curso.java.entities.Empleado;

public class TestEmpleado {
	public static void main(String[] args) {
		
		JOptionPane.showMessageDialog(null, "Hola Mundo!!!");
		
		// Objeto Mock (Objeto Simulado)
		System.out.println("-- empleado1 --");
		Empleado empleado1=new Empleado(1,"Lara","Aranda",40000);
		//empleado1.sueldoBasico=5500000;
		empleado1.setSueldoBasico(5500000);
		System.out.println(empleado1);
		
		/*
		 
		 	Modificadores de Visibilidad de miembros de clase (atributos o métodos)
		 	
		 Modificador			Alcance
		 default(Omitido)		se puede acceder desde la misma clase, o desde clases del 
		 						mismo paquete.
		 
		 public 				permite acceder desde la misma clase, o desde cualquier clase 
		 						de cualquier paquete.
		 
		 private				permite acceder solo desde la misma clase.
		 
		 protected				permite acceder al miembro desde la misma clase y desde clases
		 						hijas y desde clases del mismo paquete.
		 */
		
		//Forma de un proyecto Eclipse
		
		//UML Relaciones
		
		
	
		
		
		
		
		
		
		
		
	}
}
