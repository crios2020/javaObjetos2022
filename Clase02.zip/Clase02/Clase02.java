import java.util.Scanner;

public class Clase02 {
    public static void main(String[] args) {

        // drive :
        // https://drive.google.com/drive/folders/0B4WgLe0MzFhTMG5jRkNYY18zMjg?resourcekey=0-rkvqlWEhfBEnTqHR0Zx3ew&usp=sharing

        // canal youtube: https://www.youtube.com/channel/UCZbZVDAcSnsY5oDjxTV_-Dw

        System.out.println("-- Clase 2 --");
        // syso crtl space: atajo System.out.println();

        // Java, c#.net, Visual Basic, C++ son lenguajes Tipado Fuerte

        // Python, Javascript, PHP son lenguajes de Tipado Debil

        // Tipo de datos Java

        // Tipo de datos Enteros

        // Tipo de datos boolean 1 byte 8 bits
        boolean bo = true; // 1
        bo = false; // 0
        // bo=1; //error
        // bo=0; //error
        System.out.println(bo);

        /*
         * 0 --------
         */

        // Tipo de datos byte signed 1 byte 8 bits
        byte by = 100;
        by = -100;
        System.out.println(by);

        /*
         * byte by=100; //signed
         * 
         * |-------|-------| -128 0 127
         * 
         * 
         * byteU by //unsigned
         * 
         * |---------------| 0 255
         */

        // Tipo de datos short 2 bytes
        short sh = 20000;
        System.out.println(sh);

        // Tipo de datos int 4 bytes
        int in = 2000000000;
        System.out.println(in);

        // Tipo de datos long 8 bytes
        long lo = 3000000000L;
        System.out.println(lo);

        // Tipo de datos char 2 bytes unsigned unicode
        char ch = 65;
        ch += 32;
        ch = 'h';
        System.out.println(ch);

        // Tipo de datos de Punto Flotante

        // Tipo de datos float 32 bits
        float fl = 9.45f;
        System.out.println(fl);

        // Tipo de datos double 64 bits
        double dl = 9.45;
        System.out.println(dl);

        fl = 10;
        dl = 10;

        System.out.println(fl / 3);
        System.out.println(dl / 3);

        fl = 100;
        dl = 100;

        System.out.println(fl / 3);
        System.out.println(dl / 3);

        fl = 1000;
        dl = 1000;

        System.out.println(fl / 3);
        System.out.println(dl / 3);

        // float precio=new Scanner(System.in).nextFloat();

        // Clase BigDecimal

        // Clase String
        String st = "Hola";
        System.out.println(st);
        // System.out.println(st.value[2]);
        System.out.println(st.charAt(2));

        /*
         * JDK 9 o inferior String st="hola"; private final char[] value; // 8 bytes
         * 
         * JDK 10 o superior String st="hola"; private final byte[] value; // 4 bytes
         * 
         */

        // Tipo de datos var JDK 9 o sup
        var var1 = 2; // int
        var1 = 4000;
        // var1=4L; //error

        var var2 = true; // boolean
        var var3 = 'A'; // char
        var var4 = "A"; // String
        var var5 = 3.45f; // float
        var var6 = 3.45; // double
        var var7 = 3.45d; // double
        var var8 = 5L; // long

        // Uso de literales
        // metodo(2);
        // metodo(2L);
        // metodo(3.45);
        // metodo(3.45d);
        // metodo(3.45f);
        // metodo(true);
        // metodo('2');
        // metodo("2");

        String texto = "Esto es una cadena de caracteres!";

        System.out.println(texto);

        // recorrido de vector texto.value
        for (int a = 0; a < texto.length(); a++) {
            char car = texto.charAt(a);
            System.out.print(car);
        }
        System.out.println();

        // imprimir texto en mayusculas
        for (int a = 0; a < texto.length(); a++) {
            char car = texto.charAt(a);
            if(car>=97 && car<=122) car-=32;
            System.out.print(car);
        }
        System.out.println();

        // Operador ternario ?
        for (int a = 0; a < texto.length(); a++) {
            char car = texto.charAt(a);
            System.out.print((car>=97 && car<=122)?car-=32:car);
        }
        System.out.println();

        //Imprimir texto en minusculas
        for (int a = 0; a < texto.length(); a++) {
            char car = texto.charAt(a);
            System.out.print((car>=65 && car<=90)?car+=32:car);
        }
        System.out.println();

        System.out.println(texto.toLowerCase());
        System.out.println(texto.toUpperCase());


    }

    public static void metodo(int a) {
        System.out.println("Entero");
    }

    public static void metodo(long a) {
        System.out.println("Long");
    }

    public static void metodo(float a) {
        System.out.println("Float");
    }

    public static void metodo(double a) {
        System.out.println("Double");
    }

    public static void metodo(String a) {
        System.out.println("String");
    }

    public static void metodo(char a) {
        System.out.println("Char");
    }

    public static void metodo(boolean a) {
        System.out.println("Boolean");
    }
}
