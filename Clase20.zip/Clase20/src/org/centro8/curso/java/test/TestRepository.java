package org.centro8.curso.java.test;

import org.centro8.curso.java.connectors.Connector;
import org.centro8.curso.java.entities.Alumno;
import org.centro8.curso.java.entities.Curso;
import org.centro8.curso.java.enums.Dia;
import org.centro8.curso.java.enums.Turno;
import org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import org.centro8.curso.java.repositories.jdbc.AlumnoRepository;
import org.centro8.curso.java.repositories.jdbc.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(new Connector().getConnection());
        Curso curso=new Curso("Cocina","Mendez",Dia.JUEVES,Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        System.out.println("***************************************************");
        
        //cr.save(new Curso("Jardineria","Segovia",Dia.LUNES,Turno.MAÑANA));
        
        cr.remove(cr.getById(10));
        
        curso=cr.getById(15);
        curso.setDia(Dia.LUNES);
        curso.setProfesor("Mendoza");
        cr.update(curso);
        
        System.out.println("***************************************************");
        cr.getAll().forEach(System.out::println);
        //cr.getLikeTitulo("ja").forEach(System.out::println);
        
        System.out.println("***************************************************");
        
        I_AlumnoRepository ar=new AlumnoRepository(new Connector().getConnection());
        Alumno alumno=new Alumno("Martin", "Medrano", 30, 2);
        ar.save(alumno);
        System.out.println(alumno);
        
        ar.getAll().forEach(System.out::println);
        
    }
}
