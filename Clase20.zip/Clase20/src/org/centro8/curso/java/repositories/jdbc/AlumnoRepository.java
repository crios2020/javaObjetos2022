package org.centro8.curso.java.repositories.jdbc;

import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import org.centro8.curso.java.entities.Alumno;
import org.centro8.curso.java.entities.Curso;
import org.centro8.curso.java.enums.Dia;
import org.centro8.curso.java.enums.Turno;
import org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;

public class AlumnoRepository implements I_AlumnoRepository{

    private Connection conn;

    public AlumnoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void save(Alumno alumno) {
        if(alumno==null) return;
        try (PreparedStatement ps=conn.prepareStatement(
                "insert into alumnos (nombre,apellido,edad,idCurso) values (?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)){
            ps.setString(1, alumno.getNombre());
            ps.setString(2, alumno.getApellido());
            ps.setInt(3, alumno.getEdad());
            ps.setInt(4, alumno.getIdCurso());
            ps.execute();
            ResultSet rs=ps.getGeneratedKeys();
            if(rs.next()) alumno.setId(rs.getInt(1));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Alumno alumno) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Alumno alumno) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Alumno> getAll() {
    List<Alumno>list=new ArrayList();
        try (ResultSet rs=conn.createStatement().executeQuery("select * from alumnos")){
            while(rs.next()){
                list.add(new Alumno(
                        rs.getInt("id"),                        //id
                        rs.getString("nombre"),                 //nombre
                        rs.getString("apellido"),               //apellido
                        rs.getInt("edad"),                     //edad
                        rs.getInt("idCurso")                    //idCurso
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }
    
}
