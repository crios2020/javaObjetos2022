package org.centro8.curso.java.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import org.centro8.curso.java.entities.Curso;
import org.centro8.curso.java.enums.Dia;
public interface I_CursoRepository {
    public void save(Curso curso);
    public void remove(Curso curso);
    public void update(Curso curso);
    default Curso getById(int id){
        return getAll()
                .stream()
                .filter(c->c.getId()==id)
                .findFirst()
                .orElse(new Curso());
    }
    List<Curso>getAll();
    default List<Curso>getLikeTitulo(String titulo){
        if(titulo==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(
                        c->c.getTitulo()!= null 
                        && c.getTitulo().toLowerCase().contains(titulo.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Curso>getLikeTituloProfesor(String titulo, String profesor){
        if(titulo==null || profesor==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(
                        c->c.getTitulo()!= null && c.getProfesor()!=null
                        && c.getTitulo().toLowerCase().contains(titulo.toLowerCase())
                        && c.getProfesor().toLowerCase().contains(profesor.toLowerCase()))
                .collect(Collectors.toList());
    }
    default List<Curso>getByDia(Dia dia){
        if(dia==null) return new ArrayList();
        return getAll()
                .stream()
                .filter(c->c.getDia()!=null && c.getDia()==dia)
                .collect(Collectors.toList());
    }
}
