drop database if exists colegio;
create database colegio;
use colegio;

drop table if exists alumnos;
drop table if exists cursos;

create table cursos(
    id int primary key auto_increment,
    titulo varchar(25) not null,
    profesor varchar(25) not null,
    dia varchar(10) not null,
    turno varchar(6) not null
);

create table alumnos(
    id int primary key auto_increment,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int not null,
    idCurso int not null
);

