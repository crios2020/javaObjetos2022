package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.connectors.Connector;
import ar.org.centro8.curso.java.entities.Alumno;
import ar.org.centro8.curso.java.entities.Curso;
import ar.org.centro8.curso.java.enums.Dia;
import ar.org.centro8.curso.java.enums.Turno;
import ar.org.centro8.curso.java.repositories.interfaces.I_AlumnoRepository;
import ar.org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.AlumnoRepository;
import ar.org.centro8.curso.java.repositories.jdbc.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(new Connector().getConnection());
        Curso curso=new Curso("Cocina","Mendez",Dia.JUEVES,Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        System.out.println("***************************************************");
        
        //cr.save(new Curso("Jardineria","Segovia",Dia.LUNES,Turno.MAÑANA));
        
        cr.remove(cr.getById(10));
        
        curso=cr.getById(15);
        curso.setDia(Dia.LUNES);
        curso.setProfesor("Mendoza");
        cr.update(curso);
        
        System.out.println("***************************************************");
        cr.getAll().forEach(System.out::println);
        //cr.getLikeTitulo("ja").forEach(System.out::println);
        
        System.out.println("***************************************************");
        
        I_AlumnoRepository ar=new AlumnoRepository(new Connector().getConnection());
        Alumno alumno=new Alumno("Martin", "Medrano", 30, 2);
        ar.save(alumno);
        System.out.println(alumno);
        
        ar.remove(ar.getById(26));
        
        alumno=ar.getById(20);
        alumno.setNombre("Julian");
        alumno.setApellido("Pasco");
        ar.update(alumno);
        
        System.out.println("***************************************************");
        ar.getAll().forEach(System.out::println);
        System.out.println("***************************************************");
        ar.getByCurso(cr.getById(1)).forEach(System.out::println);
        System.out.println("***************************************************");
        ar.getLikeApellido("s").forEach(System.out::println);
        
        /*
        
        https://docs.google.com/spreadsheets/d/1g4IC2Kzqe5-qQZ-uSsmgcrn-zJVG6VlNsGPt79GIrKA/edit?usp=sharing
        
        */
        
        
        
    }
}
