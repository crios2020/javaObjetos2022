package org.centro8.curso.java.test;

import java.util.List;
import org.centro8.curso.java.utils.files.FileText;
import org.centro8.curso.java.utils.files.I_File;

public class TestFile {
    public static void main(String[] args) {
        System.out.println("Utilidad de Archivos");
        String file="texto.txt";
        I_File fText=new FileText(file);
        fText.setText("Curso de Java.\n");
        fText.appendText("Hoy es viernes!\n");
        fText.addLine("Lunes.");
        fText.addLine("Martes.");
        fText.addLine("Miércoles.");
        fText.addLine("Jueves.");
        fText.addLine("Viernes.");
        fText.addLine("Sábado.");
        fText.addLine("Domingo.");
        fText.addLine("Lunes.");
        fText.addLine("Lunes.");
        fText.addLines(List.of("Primavera","Verano","Otoño","Invierno"));
        
        //System.out.println(fText.getText());
        fText.print();
        //fText.getAll().forEach(System.out::println);
        //fText.getLikeFilter("lun").forEach(System.out::println);
        //fText.getLinkedHashSet().forEach(System.out::println);
        //fText.getTreeSet().forEach(System.out::println);
        //fText.getSortedLines().forEach(System.out::println);
        //fText.getReversedSortedLines().forEach(System.out::println);
        
    }
}
