package exepciones;

import entities.Persona;

public class GeneradorExceptions {
    public static void generar(){
        int[] vector=new int[5];
        vector[10]=20;
    }
    public static void generar(boolean x){
        if(x) System.out.println(10/0);
    }
    public static void generar(String nro){     //"23x"
        int n=Integer.parseInt(nro);
    }
    public static void generar(String text, int index){     // "hola",2
        //if(text==null || index<0 || index>=text.length()) return;
        System.out.println(text.charAt(index));
    }
    public static void generar(Object persona){
        //if(persona==null || !(persona instanceof Persona)) return;
        Persona p=(Persona)persona;
    }
}
