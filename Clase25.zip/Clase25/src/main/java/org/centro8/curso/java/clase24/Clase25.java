package org.centro8.curso.java.clase24;

public class Clase25 {
    public static void main(String[] args) {
        
        /*
                Arranque de programa
        
        tarea1: leer file 1 desde el medio 1                        10 s
        tarea2: leer file 2 desde el medio 2                        10 s
        tarea3: abrir formulario y mostrar file 1 y file 2           1 s
        
        
          Tarea 1     Tarea2   Tarea3
        |----------|----------|-|
            10 s       10 s    1 s
        
        Total 21 s
        
          Tarea 1
        |----------|
            10 s
        
          Tarea 2
        |----------|
            10 s
        
                    Tarea 3
                   |-|
                    1 s
        Total 11 s
        
        
          Tarea 1
        |----------|
            10 s
        
          Tarea 2
        |----------|
            10 s
        
          Tarea 3
        |-|
         1 s
        
        Total 10 s
        
        */
        
        
        HiloT hiloT1=new HiloT("hiloT1");
        HiloT hiloT2=new HiloT("hiloT2");
        HiloT hiloT3=new HiloT("hiloT3");
        HiloT hiloT4=new HiloT("hiloT4");
        
        //método run() - Al ejecutar directamente el método no inicia en un nuevo thread
        //hiloT1.run();
        //hiloT2.run();
        //hiloT3.run();
        //hiloT4.run();
          
        //método start() - Este método invoca al método run en un nuevo thread
        // hiloT1.start();
        // hiloT2.start();
        // hiloT3.start();
        // hiloT4.start();
        
        
        HiloR hiloR1=new HiloR("hiloR1");
        HiloR hiloR2=new HiloR("hiloR2");
        HiloR hiloR3=new HiloR("hiloR3");
        HiloR hiloR4=new HiloR("hiloR4");
        
        //Thread anonimimo
        HiloR hiloR5=new HiloR("hiloR5");
        
        
        //hiloR1.run();
        //hiloR2.run();
        //hiloR3.run();
        //hiloR4.run();
        
        Thread t1=new Thread(hiloR1);
        Thread t2=new Thread(hiloR2);
        Thread t3=new Thread(hiloR3);
        Thread t4=new Thread(hiloR4);
        
        //Runnable anonimo
        Thread t5=new Thread(new HiloR("hiloR5"));
        
        t1.start();
        t2.start();
        t3.start();
        t4.start();
        t5.start();
        new Thread(hiloR5).start();
        
        //Runnable y Thread anonimos
        new Thread(new HiloR("hiloR7")).start();
        
        
        
    }
}
