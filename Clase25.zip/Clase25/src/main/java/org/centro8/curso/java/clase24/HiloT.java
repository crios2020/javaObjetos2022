package org.centro8.curso.java.clase24;

public class HiloT extends Thread{
    private String nombre;

    public HiloT(String nombre) {
        this.nombre = nombre;
    }

    @Override
    public void run() {
        // Solamente este método puede ejecutar en un hilo en parelelo
        for(int a=1;a<=10;a++){
            System.out.println(nombre+" "+a);
            try{ Thread.sleep(1000);}catch(Exception e){}
        }
    }
    
}
