public class Clase03{
    public static void main(String[] args) {
        
        /*
            Clase 03 Programación Orientada a Objetos.

            Que es una clase: Es una plantilla para construir objetos, se detectan 
                como sustantivos. 
            
            Clases en Java: Es un objeto de la clase java.lang.Class

            Que es un atributo: El atributo describe a la clase. Son variables contenidas 
                dentro de una clase. Tienen un tipo de datos asociado. 
                La clase declara los atributos y los objetos completan estado.

                Los atributos se inicializan automaticamente.
                Los atributos numericos se inicializan en 0.
                Los atributos String se inicializan en null.

            Atributos en Java: Son objetos de la clase java.lang.reflect.Field

            Que es un método: Es una acción que realiza la clase, se detecta como verbo.

            Métodos en java: son objetos de la clase java.lang.reflect.Method


            Objetos: Son instancias de la clase, y representan una situación en particular.
                Los Objetos tienen un estado(valor en sus atributos)

            SobreCarga de métodos: ocurre cuando dos métodos en una clase tienen el mismo nombre,
                pero debe cambiar las firma de parametros de entrada.

            Métodos construtores: Los constructores sirven para iniciar objetos, El método 
                constructor se ejecuta automaticamente al iniciar un objeto, se invoca con
                la palabra new.
                El constructor tiene el mismo nombre que la clase.
                Puede crearse constructores sobrecargado
                Un constructor paramentrico exije un estado mínimo.
                Si clase no tiene constructor Java agrega un constructor en tiempo compilación

            Constructores en Java: Java creo un objeto de la clase java.lang.reflect.Constructor 

        */

        System.out.println("-- auto1 --");
        //creamos el objeto auto1
        Auto auto1=new Auto();                  //new Auto(); llamamos al constructor de la clase|

        //colocamos estado en auto1
        auto1.marca="Ford";
        auto1.modelo="Ka";
        auto1.color="Negro";
        
        //invocamos los métodos de auto1
        auto1.acelerar();       //10
        auto1.acelerar();       //20
        auto1.acelerar();       //30
        auto1.frenar();         //20
        auto1.acelerar(15);     //35
        auto1.acelerar(11);     //46

        //imprimimos el estado de auto1
        System.out.println(auto1.marca+" "+auto1.modelo+" "+auto1.color+" "+auto1.velocidad);

        //int x;
        //System.out.println(x);  //error, variable no inicializada.
        
        System.out.println("-- auto2 --");
        Auto auto2=new Auto();
        auto2.marca="Fiat";
        auto2.modelo="Idea";
        auto2.color="Rojo";

        for(int a=0;a<=60;a++) auto2.acelerar();

        System.out.println(auto2.marca+" "+auto2.modelo+" "+auto2.color+" "+auto2.velocidad);
        System.out.println(auto2);

        System.out.println("-- auto3 --");
        Auto auto3=new Auto("Peugeot","208","Gris");

        System.out.println(auto3.toString());
        System.out.println(auto3);

        // Continuar con Eclipse

    }
}
