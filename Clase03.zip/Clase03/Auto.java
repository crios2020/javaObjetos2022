//declaración de clase
public class Auto {
    
    //atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    //constructores

    /**
     * Este método fue deprecado por Carlos Ríos el 27/08/2021.
     * por resultar inseguro.
     * Usar en su reemplazo Auto(String marca, String modelo, String color)
     */
    @Deprecated         //Annotation JDK 5 o sup.
    Auto(){} //constructor vacio

    Auto(String marca, String modelo, String color) {
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
        this.velocidad = 0;
    }
   
    //métodos
    void acelerar(){                                //acelerar
        //velocidad+=10;
        //if(velocidad>100) velocidad=100;
        acelerar(10);           //Llamado de método dentro de la misma clase.
    }

    //método sobrecargado
    void acelerar(int kilometros){                  //acelerarInt
        velocidad+=kilometros;
        if(velocidad>100) velocidad=100;
    }

    //void acelerar(int r,String x){}                 //acelerarIntString

    //void acelerar(String x, int r){}                //acelerarStringInt

    void frenar(){
        velocidad-=10;
    }

    @Override
    public String toString(){
        return marca+" "+modelo+" "+color+" "+velocidad;
    }

}//end class
