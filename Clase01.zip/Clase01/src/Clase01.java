/*
	Curso: 		Programación Orientada a Objetos
	Días:		Lunes Miércoles Viernes
	Horario:	15:00 hs a 18:30 hs
	Duración: 	150 hs	43 clases.
	Profe:		Carlos Ríos		c.rios@bue.edu.ar
 
	Materiales:	https://github.com/crios2020/javaObjetos2022
	
	
	Software:	JDK - IDE.
	
	JDK: Java Development Kit	(Kit de Desarrollo Java)
	
	LTS: Long Term Support	8 años
	
	Versión				Liberado			Fin de Soporte
	JDK 8 LTS			Marzo 2014			Marzo 2022
	JDK 9				Septiembre 2017		Marzo 2018
	JDK 10				Marzo 2018			Septiembre 2018
	JDK 11 LTS			Septiembre 2018		Septiembre 2026
	JDK 12				Marzo 2019			Septiembre 2019
	JDK 13				Septiembre 2019		Marzo 2020
	JDK 14				Marzo 2020			Septiembre 2020
	JDK 15				Septiembre 2020		Marzo 2021
	JDK 16				Marzo 2021			Septiembre 2021
	JDK 17 LTS			Septiembre 2021		Septiembre 2029	
	
	IDE: Integrated Development Enviroment	(Entorno de desarrollo integrado)
	
	Visual Studio Code - Geany - Sublime Text - Notepad++ NO SON IDEs
	
	Netbeans - Eclipse - STS (Spring Tools Suite) - IntelliJ (No es Libre!)
		
*/ 

/**
 * Clase Principal del proyecto Curso Objetos Clase1
 */
public class Clase01{		//Clase Principal y publica, tiene el mismo nombre que el archivo
	
	/**
	 * Punto de entrada del proyecto
	 * @param args Argumentos que ingresan por consola
	 */
	public static void main(String[] args){ //método main
		//Punto de entrada
		System.out.println("Hola Mundo");
		
		// Comentarios de una sola linea.
		
		/* Bloque de comentarios */
		
		/**
			Comentarios Java DOC
			Tiene la posilidad de ser visto desde fuera del binario.
			Sirve para documentar el proyecto.
			Este comentario debe agregarse delante de la declaración de métodos 
			o delante de la declaración de clases
		*/
		
		//String[] args
		//Vector con Argumentos desde consola
		System.out.println("Cantidad de Argumentos: "+args.length);
		for(int a=0;a<args.length;a++){
			System.out.println(args[a]);
		}
		
		
		
		
	}
}
