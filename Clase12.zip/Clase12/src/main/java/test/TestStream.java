package test;

import entities.Persona;
import enums.EstadoCivil;
import java.util.Comparator;
import java.util.List;

public class TestStream {
    public static void main(String[] args) {
        List<Persona>list=List.of(
                new Persona("Laura","Salinas",26,EstadoCivil.CASADO),
                new Persona("Debora","Vargas",23,EstadoCivil.DIVORCIADO),
                new Persona("Karina","Vasquez",38,EstadoCivil.SOLTERO),
                new Persona("Sabrina","Rieras",39,EstadoCivil.SOLTERO),
                new Persona("Pedro","Monic",65,EstadoCivil.UNIONCIVIL),
                new Persona("Mariano","Eliano",29,EstadoCivil.SOLTERO),
                new Persona("Cristian","Molina",71,EstadoCivil.VIUDO),
                new Persona("Jose","Monez",28,EstadoCivil.CASADO),
                new Persona("Cristina","Marciana",45,EstadoCivil.CASADO),
                new Persona("Gerardo","Alfaro",50,EstadoCivil.CASADO),
                new Persona("Solange","Lopez",26,EstadoCivil.SOLTERO),
                new Persona("Laura","Lopez",71,EstadoCivil.SOLTERO),
                new Persona("laura","Garcia",26,EstadoCivil.SOLTERO),
                new Persona("LAURA","Molina",26,EstadoCivil.SOLTERO),
                new Persona("Lautaro","Molina",28,EstadoCivil.SOLTERO),
                new Persona("Beatriz","Lopez",28,EstadoCivil.SOLTERO),
                new Persona("Ana","Lopez",71,EstadoCivil.SOLTERO),
                new Persona("Cecilia","Lopez",28,EstadoCivil.SOLTERO),
                new Persona("Leon","Sarabia",23,EstadoCivil.SOLTERO)
        );
        
        System.out.println("****************************************************");
        //select * from personas;
        list.forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        //select * from personas where nombre='laura';
        //for(Persona p:list){
        //    if(p.getNombre().equalsIgnoreCase("Laura")) System.out.println(p);
        //}
        
        list
                .stream()
                .filter(p->p.getNombre().equalsIgnoreCase("Laura"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like 'lau%';
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("lau"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like 'lau%' and estadoCivil=='SOLTERO';
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().startsWith("lau")
                        && p.getEstadoCivil()==EstadoCivil.SOLTERO )
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like '%a';
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like '%an%';
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().contains("an"))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas where nombre like '%a' and edad>30;
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a")
                        && p.getEdad()>30)
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas order by nombre;
        
        //Orden Natural
        //list
        //        .stream()
        //        .sorted()
        //        .forEach(System.out::println);
        
        list
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas order by nombre desc;
        list
                .stream()
                .sorted(Comparator.comparing(Persona::getNombre).reversed())
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas order by apellido, nombre;
        list
                .stream()
                .sorted(Comparator.comparing(Persona::getApellido).thenComparing(Persona::getNombre))
                .forEach(System.out::println);
        
        System.out.println("****************************************************");
        //select * from personas order by edad, apellido, nombre;
        list
                .stream()
                .sorted(Comparator.comparingInt(Persona::getEdad).thenComparing(Persona::getApellido).thenComparing(Persona::getNombre))
                .forEach(System.out::println);
        
         System.out.println("****************************************************");
        //select * from personas order by edad desc, apellido, nombre;
        list
                .stream()
                .sorted(Comparator.comparingInt(Persona::getEdad).reversed().thenComparing(Persona::getApellido).thenComparing(Persona::getNombre))
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        //select * from personas where nombre like '%a' order by edad;
        list
                .stream()
                .filter(p->p.getNombre().toLowerCase().endsWith("a"))
                .sorted(Comparator.comparingInt(Persona::getEdad))
                .forEach(System.out::println);
        
        
        // pendientes min max count
        System.out.println("****************************************************");
        //select min(edad) from personas;
        int edadMinima=list
                .stream()
                .min(Comparator.comparingInt(Persona::getEdad))
                .get()
                .getEdad();
        System.out.println("Edad mínima es: "+edadMinima);
        
        System.out.println("****************************************************");
        //Personas que tiene la edad mínima
        //select * from personas where edad=(select min(edad) from personas);
        list
                .stream()
                .filter(p->p.getEdad()==edadMinima)
                .forEach(System.out::println);
        
        
        System.out.println("****************************************************");
        //select max(edad) from personas;
        int edadMaxima=list
                .stream()
                .max(Comparator.comparingInt(Persona::getEdad))
                .get()
                .getEdad();
        
        System.out.println("Edad máxima es: "+edadMaxima);
        
        System.out.println("****************************************************");
        //Personas que tiene la edad máxima
        //select * from personas where edad=(select max(edad) from personas);
        list
                .stream()
                .filter(p->p.getEdad()==edadMaxima)
                .forEach(System.out::println);
        
        
        list
                .stream()
                .filter(p->p.getEdad()==edadMaxima)
                .forEach(p->System.out.println(p.getNombre()+" "+p.getApellido()));
        
        // Laboratorio
        
        System.out.println("Marca: Peugeot // Modelo: 206 // Puertas: 4 // Precio: $200.000,00\n" +
"\n" +
"Marca: Honda // Modelo: Titan // Cilindrada: 125c // Precio: $60.000,00\n" +
"\n" +
"Marca: Peugeot // Modelo: 208 // Puertas: 5 // Precio: $250.000,00\n" +
"\n" +
"Marca: Yamaha // Modelo: YBR // Cilindrada: 160c // Precio: $80.500,50");
        
        // Api Reflect
        
        
        
    }
}
