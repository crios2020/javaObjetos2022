package test;

import entities.Auto;
import entities.Persona;
import enums.EstadoCivil;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class TestApiReflect {
    public static void main(String... args) throws Exception {
        //api reflect
        Object o=new Persona("Juan", "Perez", 38, EstadoCivil.UNIONCIVIL);
        
        //Objeto Class
        System.out.println("-- Class --");
        System.out.println(o.getClass().getName());
        System.out.println(o.getClass().getSimpleName());
        System.out.println(o.getClass().getSuperclass().getName());
        
        //Objetos Fields (Atributos)
        System.out.println("-- Atributos privados--");
        Field[] campos=o.getClass().getDeclaredFields();
        for(Field f:campos) System.out.println(f.getName()+" "+f.getType().getName());
        
        System.out.println("-- Atributos publicos--");
        campos=o.getClass().getFields();
        for(Field f:campos) System.out.println(f.getName()+" "+f.getType().getName());
        
        //Objetos Methods (Métodos)
        System.out.println("-- Metodos --");
        Method[] metodos=o.getClass().getDeclaredMethods();
        for(Method m:metodos) {
            System.out.println("nombre: "+m.getName()+" devuelve: "+m.getGenericReturnType().getTypeName());
            System.out.println("\tParametros:");
            for(Parameter p:m.getParameters()){
                System.out.println("\t\t"+p.getName()+" "+p.getParameterizedType().getTypeName());
            }
        }
        
        System.out.println("-- Metodos Heredados--");
        metodos=o.getClass().getMethods();
        for(Method m:metodos) {
            System.out.println("nombre: "+m.getName()+" devuelve: "+m.getGenericReturnType().getTypeName());
            System.out.println("\tParametros:");
            for(Parameter p:m.getParameters()){
                System.out.println("\t\t"+p.getName()+" "+p.getParameterizedType().getTypeName());
            }
        }
       
        // getConstructors
        System.out.println("-- Constructores --");
        Constructor[] constructores=o.getClass().getConstructors();
        for(Constructor c:constructores){
            System.out.println("nombre: "+c.getName());
            System.out.println("\tParametros:");
            for(Parameter p:c.getParameters()){
                System.out.println("\t\t"+p.getName()+" "+p.getParameterizedType().getTypeName());
            }
        }

        //invoke
        System.out.println(o);
        
        o.getClass().getMethod("setNombre", String.class).invoke(o, "Carlos");
        
        System.out.println(o);
        
        o=new Auto("Fiat", "Idea", "Gris");
        System.out.println(o);
        System.out.println("****************************************************");
        
        for(Field f: o.getClass().getDeclaredFields()){
            String nombre="get"+f.getName().substring(0,1).toUpperCase()+f.getName().substring(1);
            System.out.println(o.getClass().getMethod(nombre).invoke(o));
        }
        
        //varArgs JDK 5
        String[] semana={"lunes","martes","miércoles","jueves","viernes","sábado","domingo"};
        metodo1(semana);
        metodo2(semana);
        
        //metodo1("primavera","verano","otoño","invierno"); //error
        metodo2("primavera","verano","otoño","invierno");
        metodo2("lunes","martes","miércoles","jueves","viernes","sábado","domingo");
        
        
    }
    
    public static void metodo1(String[] vector){
        for(int a=0; a<vector.length;a++) System.out.println(vector[a]);
    }
    
    public static void metodo2(String... args){
        for(int a=0; a<args.length;a++) System.out.println(args[a]);
    }
}
