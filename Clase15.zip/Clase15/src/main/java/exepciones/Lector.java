package exepciones;

import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Lector implements Closeable {
    private FileReader in=new FileReader("texto.txt");

    public Lector() throws FileNotFoundException {
        in=new FileReader("texto.txt");    
    }
 
    public int leer() throws IOException{
        return in.read();
    }
    
    @Override
    public void close() throws IOException {
        System.out.println("Se ejecuto el método close()");
        in.close();
    }
    
}
