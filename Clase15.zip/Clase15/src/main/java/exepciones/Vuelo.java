package exepciones;

public class Vuelo {
    private String nombreVuelo;
    private int cantidadPasajes;

    public Vuelo(String nombreVuelo, int cantidadPajes) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajes = cantidadPajes;
    }

    public synchronized void venderPasajes(int cantidadPasajesPedidos) throws NoHayMasPasajesException{
        if(cantidadPasajesPedidos>cantidadPasajes){
            throw new NoHayMasPasajesException(nombreVuelo, cantidadPasajes, cantidadPasajesPedidos);
        }
        cantidadPasajes-=cantidadPasajesPedidos;
    }
    
    @Override
    public String toString() {
        return "Vuelo{" + "nombreVuelo=" + nombreVuelo + ", cantidadPajes=" + cantidadPasajes + '}';
    }

    public void setNombreVuelo(String nombreVuelo) {
        this.nombreVuelo = nombreVuelo;
    }

    public void setCantidadPajes(int cantidadPajes) {
        this.cantidadPasajes = cantidadPajes;
    }
    
}
