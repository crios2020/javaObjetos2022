package exepciones;

public class NoHayMasPasajesException extends Exception{
    private String nombreVuelo;
    private int cantidadPasajesDisponibles;
    private int cantidadPasajesPedidos;

    public NoHayMasPasajesException(String nombreVuelo, int cantidadPasajesDisponibles, int cantidadPasajesPedidos) {
        this.nombreVuelo = nombreVuelo;
        this.cantidadPasajesDisponibles = cantidadPasajesDisponibles;
        this.cantidadPasajesPedidos = cantidadPasajesPedidos;
    }

    @Override
    public String toString() {
        return getMessage();
    }

    @Override
    public String getMessage() {
        return "El vuelo "+nombreVuelo+" no tiene "+cantidadPasajesPedidos+" pasajes, solo tiene "+cantidadPasajesDisponibles+" pasajes";
    }

    public String getNombreVuelo() {
        return nombreVuelo;
    }

    public int getCantidadPasajesDisponibles() {
        return cantidadPasajesDisponibles;
    }

    public int getCantidadPasajesPedidos() {
        return cantidadPasajesPedidos;
    }
 
}
