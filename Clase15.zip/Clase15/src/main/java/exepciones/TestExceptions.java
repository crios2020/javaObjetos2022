package exepciones;

import entities.Auto;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestExceptions {
    public static void main(String[] args){
        
        //System.out.println(10/0);
        //System.out.println("esta linea no se ejecuta");
        
        /*
            Estructura Try - Catch - Finally
        
        try{                                        //Obligatorio
            - Colocar aca las sentencias que pueden lanzar una Exception.
            - Estas sentencias tienen más costo de hardware.
            - Si se ejecutan bien estas sentencias, termina el bloque 
                y continua ejecutando el bloque finally.
            - Si al ejecutar ocurrio una Exception, el programa no se detiene
                y continua ejecutando el el bloque catch.
        } catch(Exception e){                       //Obligatorio
            - Este bloque se ejecuta en caso de lanzar exception el bloque try.
            - Se recibe como parametro un objeto de Exception, con las caracteristicas 
                del error.
            - Cuando termina de ejecutar el bloque (catch), continua ejecutando el 
                bloque finally
        } finally                                   //Opcional
            - Este bloque se ejecuta siempre.
            - Las variables declaradas en Try o Catch esta fuera de Scope
        }
        
        - El programa termina normalmente
        */
        
        /*
        try{
            System.out.println(10/0);
            System.out.println("esta linea no se ejecuta");
        }catch(Exception e){
            System.out.println("Ocurrio un error!");
            System.out.println(e);
        }finally{
            System.out.println("Este bloque se ejecuta siempre!");
        }
        System.out.println("El programa termina normalmente");
        */
        
        //Unchecked Exceptions Extienden de RuntimeException
        //GeneradorExceptions.generar(new Auto("Ford","Fiesta","Verde"));
        
        //CheckedException
        //FileReader in=new FileReader("texto.txt");
        
        try {
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("38v");
            //GeneradorExceptions.generar("hola", 20);
            //GeneradorExceptions.generar(null, 2);
            //GeneradorExceptions.generar(new Auto("Ford","Fiesta","Verde"));
            //FileReader in=new FileReader("texto.txt");
            //System.out.println("Esta linea no se ejecuta");
        } catch (Exception e) {
            System.out.println(e);
        }
        
        //Captura personalizada de Exception
        try {
            //GeneradorExceptions.generar(true);
            //GeneradorExceptions.generar("38v");
            //GeneradorExceptions.generar(null, 2);
            //GeneradorExceptions.generar(new Auto("Ford","Fiesta","Verde"));
            //GeneradorExceptions.generar();
            //GeneradorExceptions.generar("hola", 20);
            FileReader in=new FileReader("texto.txt");
        } catch (ArithmeticException e)             { System.out.println("División /0");
        } catch (NumberFormatException e)           { System.out.println("Formato de número incorrecto!");
        } catch (NullPointerException e)            { System.out.println("Puntero Nulo!");
        } catch (ClassCastException e)              { System.out.println("Clase Incorrecta!");
        //} catch (ArrayIndexOutOfBoundsException e)  { System.out.println("Indice Incorrecto!");
        //} catch (StringIndexOutOfBoundsException e) { System.out.println("Indice Incorrecto!");
        //} catch (ArrayIndexOutOfBoundsException | StringIndexOutOfBoundsException e) { System.out.println("Indice Incorrecto!");
        } catch (IndexOutOfBoundsException e)       { System.out.println("Indice Incorrecto!");
        } catch (FileNotFoundException e)           { System.out.println("Archivo no Encontrado!");
        } catch (IOException e)                     { System.out.println("Error IO!");
        } catch (Exception e)                       { System.out.println("Ocurrio un error no esperado!"); }
                
        // Uso De Exception para validar Reglas de negocio
        
        Vuelo v1=new Vuelo("AER1234", 100);
        Vuelo v2=new Vuelo("LAT1111", 100);
        
        
        try {
            v1.venderPasajes(50);
            v2.venderPasajes(10);
            v1.venderPasajes(30);
            v2.venderPasajes(20);
            v1.venderPasajes(30);                   //Lanza Exception
            v2.venderPasajes(10);                   //Esta venta no se hace
        } catch (NoHayMasPasajesException ex) {
            System.out.println(ex);
        }
  
//        try{
//            Lector lector=new Lector();
//            try {
//                System.out.println(lector.leer());
//                lector.close();
//            } catch (Exception e) {
//                System.out.println(e);
//                if(lector!=null){
//                    lector.close();
//                }
//            } 
//        }catch(Exception e){
//            System.out.println(e);
//        }
        
        //try with resorces JDK 7
        try (Lector lector=new Lector()){
            System.out.println((char)lector.leer());
            lector.close();
        } catch (Exception e) {
            System.out.println(e);
        }
 
    }
}