package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Cliente;
import ar.org.centro8.curso.java.entities.Cuenta;
import ar.org.centro8.curso.java.entities.Direccion;
import ar.org.centro8.curso.java.entities.Empleado;
import ar.org.centro8.curso.java.entities.Persona;
import ar.org.centro8.curso.java.entities.Vendedor;

public class TestHerencia {
	public static void main(String[] args) {
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1 = new Cuenta(1,"arg$");
		cuenta1.depositar(80000);
		cuenta1.depositar(120000);
		cuenta1.debitar(32000);
		System.out.println(cuenta1);
		
		System.out.println("-- dir1 --");
		Direccion dir1=new Direccion("Larrea",22,"1","b");
		System.out.println(dir1);
		
		System.out.println("-- dir2 --");
		Direccion dir2=new Direccion("Belgrano",49,null,null,"Moron");
		System.out.println(dir2);
		
		/*
		System.out.println("-- persona1 --");
		Persona persona1=new Persona("Juan",38,dir1);
		persona1.saludar();
		System.out.println(persona1);

		System.out.println("-- persona2 --");
		Persona persona2=new Persona("Sabrina",39,persona1.getDireccion());
		persona2.saludar();
		System.out.println(persona2);
		*/
		
		System.out.println("-- vendedor1 --");
		Vendedor vendedor1=new Vendedor("Laura",26,dir2,1,120000);
		vendedor1.saludar();
		System.out.println(vendedor1);
		
		System.out.println("-- cliente1 --");
		Cliente cliente1=new Cliente("Debora",23,new Direccion("Darragueira",111,null,null),1,cuenta1);
		cliente1.saludar();
		System.out.println(cliente1);
		
		System.out.println("hola".getClass());
		System.out.println(vendedor1.getClass());
		System.out.println(cliente1.getClass());
		System.out.println(cliente1.getClass().getName());
		System.out.println(cliente1.getClass().getSimpleName());
		System.out.println(cliente1.getClass().getSuperclass().getName());
		System.out.println(cliente1.getClass().getSuperclass().getSuperclass().getName());
		System.out.println("hola".getClass().getSuperclass().getName());
		System.out.println(
			cliente1
				.getClass()
				.getSuperclass()
				.getSuperclass()
				.getSuperclass()
		);
		
		
		
		// Poliformismo poliformismo
		Persona p1=new Vendedor("Ana",29,dir1,10,150000);
		Persona p2=new Cliente("Julian",60,dir2,10,cuenta1);
		p1.saludar();
		p2.saludar();
		
		Vendedor v1=(Vendedor)p1;
		Vendedor v2=(p1 instanceof Vendedor)?(Vendedor)p1:null;
		
		
		// Pendientes Fabrica de chocolates - Static - Interfaces
		
		
		
		
		
		
		
		
	}
}
