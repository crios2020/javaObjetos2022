-- drop database if exists colegio;
-- create database colegio;
-- use colegio;

drop table if exists alumnos;
drop table if exists cursos;

create table cursos(
    id int primary key auto_increment,
    titulo varchar(25) not null,
    profesor varchar(25) not null,
    dia varchar(10) not null,
    turno varchar(6) not null
);

create table alumnos(
    id int primary key auto_increment,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    edad int not null,
    idCurso int not null
);

-- creamos la restricción Foreign Key
alter table alumnos
	add constraint FK_alumnos_idCurso
    foreign key(idCurso)
    references cursos(id);

show tables;
select * from alumnos;
select * from cursos;

-- error
-- insert into alumnos (nombre,apellido,edad,idCurso) values ('Ana','Jerez',38,5);