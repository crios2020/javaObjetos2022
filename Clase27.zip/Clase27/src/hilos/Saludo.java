package hilos;

public class Saludo {
    public synchronized void saludar(String nombre, boolean esJefe){
        try {
            if(esJefe){
                System.out.println("Jefe: Hola llegue!!!");
                //notifyAll();
                
                for(int a=1;a<=20;a++){
                    notify();
                    try{ Thread.sleep(20); }catch(Exception e){}
                }
                notifyAll();
            }else{
                System.out.println("Llego "+nombre);
                wait();
                System.out.println(nombre+": Hola Jefe!!!");
            }
            
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
