package hilos;

import java.util.Collections;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class App {
    public static void main(String[] args) throws Exception{
        Cuenta cuenta=new Cuenta();
        
        Cliente c1=new Cliente(cuenta);
        Cliente c2=new Cliente(cuenta);
        
        c1.start();
        c2.start();
        c1.join();
        c2.join();
        System.out.println(cuenta.getSaldo());
        
        
        /*
            Que diferencia hay entre Hashtable y HashMap?
        
        HashMap:
            - HashMap sus métodos no estan sincronizados
            - Es veloz
            - No sirve para Multihread
        
        Hashtable:
            - Hashtable sus métodos estan sincronizados
            - Es lento
            - Sirve para Multithread
        
        Collections.toMap():            
            - JDK 7 o sup.
            - Fabrica un mapa con métodos parcialmente sincronizados
            - Sirve para Multithread
        
        */
        
        //HashMap<String,String> map=new HashMap();
        //Hashtable<String,String> map=new Hashtable();
        Map<String,String>map=Collections.synchronizedMap(new HashMap<String,String>());
        
        //app
        map.put("lu", "Lunes");
        map.put("ma", "Martes");
        map.put("mi", "Miércoles");
        map.put("ju", "Jueves");
        map.put("vi", "Viernes");
        System.out.println(map.get("ju"));
        System.out.println("****************************************************");
        map.forEach((k,v)->System.out.println(k+":"+v));
        
        
        
        //StringBuffer sb=new StringBuffer();
        //StringBuilder sb=new StringBuilder();
        
        
        
    }
}
