package hilos;

public class Cuenta {
    private double saldo=5000;
    
    public void debitar(double monto){
        System.out.println("-- Iniciando operación debitar --");
        synchronized(this){ //sincronizado parcial JDK o sup
            if(saldo>=monto){
                try{ Thread.sleep(2000); }catch(Exception e){}
                saldo=saldo-monto;
            }else{
                System.out.println("Saldo Insuficiente!");
            }
        }
        System.out.println("-- Final de operación debitar --");
    }

    public synchronized void depositar(double monto){
        saldo+=monto;
    }
    
    public synchronized double getSaldo() {
        return saldo;
    }
 
}
