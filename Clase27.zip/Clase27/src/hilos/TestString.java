package hilos;

public class TestString {
    public static void main(String[] args) {
        String text="";
        //StringBuffer sb=new StringBuffer();
        StringBuilder sb=new StringBuilder();
        for(int a=1;a<=1000000;a++){
            //text+="x";
            sb.append("x");
        }
    }
}
