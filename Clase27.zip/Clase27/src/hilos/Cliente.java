package hilos;

public class Cliente extends Thread{
    private Cuenta cuenta;

    public Cliente(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

    @Override
    public void run() {
        cuenta.debitar(5000);
        System.out.println("Saldo: "+cuenta.getSaldo());
    }
    
    
}
