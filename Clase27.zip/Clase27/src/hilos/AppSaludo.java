package hilos;

public class AppSaludo {
    public static void main(String[] args) {
        Saludo saludo=new Saludo();
        
        Empleado luis=new Empleado("luis",false,saludo);
        Empleado laura=new Empleado("laura",false,saludo);
        Empleado jose=new Empleado("jose",false,saludo);
        Empleado maria=new Empleado("maria",false,saludo);
        Empleado jefe=new Empleado("jefe",true,saludo);
        
        
        luis.start();
        laura.start();
        jose.start();
        maria.start();
        try{ Thread.sleep(200); }catch(Exception e){}
        jefe.start();
    }
}
