package org.centro8.curso.java.test;

import org.centro8.curso.java.connectors.Connector;
import java.sql.Connection;
import java.sql.ResultSet;
import java.time.Duration;
import java.time.LocalDateTime;
public class TestConnector {
    public static void main(String[] args) {
        LocalDateTime ldtInicio=LocalDateTime.now();
        /*
            db4free.net 
            
            "jdbc:mariadb://db4free.net:3306/negociowebcfp8?serverTimezone=UTC","centro_8","centro_8"
        */
        
        /*
        Postgre
        "jdbc:postgresql://kesavan.db.elephantsql.com:5432/kwugovfe","kwugovfe","e3SF33nVwgZkZjAOzjT4Bs8MHuWcyfD6"
        
        */
        
        try (Connection conn=new Connector().getConnection()){
            ResultSet rs=conn
                    .createStatement()
                    .executeQuery("select version()");
            if(rs.next()) System.out.println(rs.getString(1));
        } catch (Exception e) {
            System.out.println("");
        }
        LocalDateTime ldtFin=LocalDateTime.now();
        Duration duration = Duration.between(ldtInicio, ldtFin);
        System.out.println("Tiempo: "+duration.getSeconds()+" segundos.");
    }
}
