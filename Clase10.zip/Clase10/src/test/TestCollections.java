package test;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Stack;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.Vector;

import entities.Auto;

public class TestCollections {
	public static void main(String[] args) {
		//Clase 09 Frameworks Collections
		
		
		//Vectores o Arrays
		Auto[] autos=new Auto[4];
		autos[0] = new Auto("Fiat","Uno","Blanco");
		autos[1] = new Auto("Ford","Ka","Negro");
		autos[2] = new Auto("Citroen","Berlingo","Rojo");
		autos[3] = new Auto("Peugeot","208","Gris");
		
		//Recorrido con indices
		//for(int a=0;a<autos.length;a++) System.out.println(autos[a]);
		
		//forEach JDK 5 o sup.
		//for(Auto a:autos) System.out.println(a);
		
		// Método forEach
		List.of(autos).forEach(System.out::println);
		
		//Interface List
		List lista1;
		
		lista1=new ArrayList();
		//lista1=new LinkedList();
		//lista1=new Vector();
		
		lista1.add(new Auto("Chevrolet","Corsa","Verde"));			// 0
		lista1.add(new Auto("Fiat","Idea","Rojo"));					// 1
		lista1.add("Hola Mundo");									// 2
		lista1.add("Chau Mundo");;									// 3
		lista1.add(26);												// 4
		lista1.remove(2);
		lista1.add(2,"Curso de Java");
		
		//Copiar vector autos a lista1
		//for(Auto a:autos) lista1.add(a);
		lista1.addAll(Arrays.asList(autos));
		
		System.out.println("********************************************");
		//Recorrido con indices
		//for(int a=0;a<lista1.size();a++) System.out.println(lista1.get(a));
		
		//Recorrido con forEach
		//for(Object o:lista1) System.out.println(o);
		
		//Metodo default forEach JDK 8 o sup.
		//lista1.forEach(o->{
		//	System.out.println(o);
		//});
		
		//lista1.forEach(o->System.out.println(o));
		
		lista1.forEach(System.out::println);
		
		//Uso de Generics <> 		JDK 5 o sup.
		List<Auto> lista2=new ArrayList();
		lista2.add(new Auto("VW","Gol","Blanco"));
		lista2.add(new Auto("Citroen","Berlingo","Bordo"));
		
		Auto a1=(Auto)lista1.get(0);
		Auto a2=lista2.get(0);
		
		//copiar autos de lista1 a lista2
		lista1.forEach(o->{
			if(o instanceof Auto) lista2.add((Auto)o);
		});
		
		System.out.println("********************************************");
		lista2.forEach(System.out::println);
		
		
		//Interface Set
		Set<String> set=null;
		
		//Implementación HashSet: Es la más veloz, no garantiza el orden de los elementos
		//set=new HashSet();
		
		//Implementación LinkedHashSet:	Almacena elementos en una lista enlazada por orden de ingreso
		//set=new LinkedHashSet();
		
		//Implementación TreeSet: Almacena elementos en un arbol por orden natural.
		set=new TreeSet();
		
		//appSet
		set.add("Lunes");
		set.add("lunes");
		set.add("Martes");
		set.add("Miércoles");
		set.add("Jueves");
		set.add("Viernes");
		set.add("Lunes");
		set.add("Viernes");
		set.add("Lunes");
		set.add("Sábado");
		set.add("Domingo");
		set.forEach(System.out::println);
		
		Set<Auto>setAutos;
		//setAutos=new LinkedHashSet();
		setAutos=new TreeSet();
		
		setAutos.add(new Auto("Peugeot","Partner","Amarilla"));
		setAutos.addAll(lista2);
		setAutos.add(new Auto("Peugeot","208","Gris"));
		
		
		setAutos.forEach(a->System.out.println(a+"\t"+a.hashCode()));
		
		
		//Pilas Stack      LIFO (Last In First Out)
		Stack<Auto>pilaAutos=new Stack();
		pilaAutos.push(new Auto("Fiat","Idea","Rojo"));	//.push() Apila un elemento en la pila
		pilaAutos.addAll(lista2);
		System.out.println("*****************************************************************");
		pilaAutos.forEach(System.out::println);
		System.out.println("Longitud de pila: "+pilaAutos.size());
		while(!pilaAutos.isEmpty()) {
			System.out.println(pilaAutos.pop()); 		//.pop() Desapila un elemento de la pila
		}
		System.out.println("Longitud de pila: "+pilaAutos.size());
		
		
		//Colas ArrayDeque		FIFO (First In First Out)
		ArrayDeque<Auto> colaAutos=new ArrayDeque();
		colaAutos.offer(new Auto("VW","Polo","Gris"));	//.offer() Encolar un elemento a la cola
		colaAutos.addAll(lista2);
		System.out.println("*****************************************************************");
		colaAutos.forEach(System.out::println);
		System.out.println("Longitud de Cola: "+colaAutos.size());
		while(!colaAutos.isEmpty()) {
			System.out.println(colaAutos.poll()); 		//.poll() Desencola un elemento de la cola
		}
		System.out.println("Longitud de Cola: "+colaAutos.size());
		
		
		//Mapas
		Map<String,String> mapaSemana=null;
		
		//Implementación HashMap: es la más veloz, no garantiza el orden de los elementos
		//mapaSemana=new HashMap();
		
		//Implementación Hashtable(): es igual a HashMap, pero es obsoleta
		//mapaSemana=new Hashtable();
		
		//Implementación LinkedHashMap: Almacena elementos en una lista enlazada por orden de ingreso
		//mapaSemana=new LinkedHashMap();
		
		//Implementación TreeMap:	Almacena elementos en una arbol ordenandos por orden natural
		mapaSemana=new TreeMap();
		
		mapaSemana.put("lu", "Lunes");
		mapaSemana.put("ma", "Martes");
		mapaSemana.put("mi", "Miércoles");
		mapaSemana.put("ju", "Jueves");
		mapaSemana.put("vi", "Viernes");
		mapaSemana.put("sa", "Sábado");
		mapaSemana.put("do", "Domingo");
		System.out.println(mapaSemana.get("mi"));
		System.out.println("***********************************************************");
		mapaSemana.forEach((k,v)->System.out.println(k+" "+v));
		
		System.getProperties().forEach((k,v)->System.out.println(k+": "+v));
		System.getenv().forEach((k,v)->System.out.println(k+": "+v));
		
		
		// Api Stream JDK 8 o sup
		System.out.println("***********************************************************");
		//select * from autos where color='rojo';
		lista2
			.stream()
			.filter(a->a.getColor().equalsIgnoreCase("rojo"))
			.forEach(System.out::println);
		
		
		System.out.println("***********************************************************");
		//select * from autos where marca='Fiat' and color='rojo';
		lista2
			.stream()
			.filter(a->a.getMarca().equalsIgnoreCase("fiat") && a.getColor().equalsIgnoreCase("rojo"))
			.forEach(System.out::println);
		
		
		System.out.println("***********************************************************");
		//select * from autos where marca like 'f%';
		lista2
			.stream()
			.filter(a->a.getMarca().toLowerCase().startsWith("f"))
			.forEach(System.out::println);
		
		System.out.println("***********************************************************");
		//select * from autos where marca like '%i%';
		lista2
			.stream()
			.filter(a->a.getMarca().toLowerCase().contains("i"))
			.forEach(System.out::println);
		
		
		// > >= max min count orderby 
		
		
	}
}
