package org.centro8.curso.java.clase24;

public class Clase24 {
    public static void main(String[] args) {
        System.out.println("Clase 24");
        System.out.println(System.getProperty("java.version"));
        

        
    }
}
