
public class Dato {
	int dato;

	public Dato(int dato) {
		super();
		this.dato = dato;
	}

	@Override
	public String toString() {
		return "Dato [dato=" + dato + "]";
	}

	@Override
	public int hashCode() {
		return toString().hashCode();
	}

	@Override
	public boolean equals(Object obj) {
		return this.hashCode()==obj.hashCode();
	}
	
}
