import java.util.Scanner;

public class Clase08 {

	public static void main(String[] args) {
		// Clase 08
		
		// Clase Object

		
		Dato d1=new Dato(2);
		Dato d2=d1;
		Dato d3=new Dato(d1.dato);
		Dato d4=new Dato(3);
		String d5="2";
		
		//método hashCode
		System.out.println("d1.hashCode(): "+d1.hashCode());
		System.out.println("d2.hashCode(): "+d2.hashCode());
		System.out.println("d3.hashCode(): "+d3.hashCode());
		System.out.println("d4.hashCode(): "+d4.hashCode());
		System.out.println("d5.hashCode(): "+d5.hashCode());
		
		//método equals
		System.out.println("d1.equals(d1): "+d1.equals(d1));
		System.out.println("d1.equals(d2): "+d1.equals(d2));
		System.out.println("d1.equals(d3): "+d1.equals(d3));
		System.out.println("d1.equals(d4): "+d1.equals(d4));
		System.out.println("d1.equals(d5): "+d1.equals(d5));
		
		
		//Clase String
		String texto="Hola";
		String texto2=new String("Hola");
		char[] vector= {'h','o','l','a'};
		String texto3=new String(vector);
		String texto4="Esto es una cadena de caracteres!";
		
		//método length
		System.out.println(texto4.length());
		
		//método charAt(int)
		System.out.println(texto.charAt(2));
		
		//método trim()
		System.out.println("  hola como estas?   ".trim());
		
		//método substring
		System.out.println(texto4.substring(5, 15));
		System.out.println(texto4.substring(10));
		
		//startsWith() endsWith()
		System.out.println(texto.startsWith("h"));
		System.out.println(texto.startsWith("Ho"));
		System.out.println(texto.endsWith("a"));
		
		//contains
		System.out.println(texto.contains("z"));
		System.out.println(texto.contains("a"));
		
		//split()
		String[] palabras=texto4.split(" ");
		for(int a=0;a<palabras.length;a++) {
			System.out.println(palabras[a]);
		}
		
		// Clase System
		
		//método .exit()
		//System.exit(0);
		//System.out.println("esta linea no se ejecuta!");
		
		//.out	Stream sincronizado de salida a consola.
		//.err	Stream no sincronizado de salida a consola.
		//.in	Stream sincronzado de entrada de consola.
		
		System.out.println("Curso de Java 1");
		System.out.println("Curso de Java 2");
		System.out.println("Curso de Java 3");
		System.out.println("Curso de Java 4");
		System.out.println("Curso de Java 5");
		System.out.println("Curso de Java 6");
		System.out.println("Curso de Java 7");
		System.out.println("Curso de Java 8");
		System.out.println("Curso de Java 9");
		System.out.println("Curso de Java 10");
		System.out.println("Curso de Java 11");
		System.out.println("Curso de Java 12");
		System.out.println("Curso de Java 13");
		System.out.println("Curso de Java 14");
		System.out.println("Curso de Java 15");
		System.out.println("Curso de Java 16");
		System.out.println("Curso de Java 17");
		System.out.println("Curso de Java 18");
		System.out.println("Curso de Java 19");
		System.out.println("Curso de Java 20");
		System.err.println("Ocurrio un error!");
		
		//System.out.println("Ingrese su nombre: ");
		//String nombre=new Scanner(System.in).nextLine();
		
		//.getProperties
		System.out.println(System.getProperties());
		String[] propiedades=System.getProperties().toString().split(", ");
		for(int a=0;a<propiedades.length;a++) {
			System.out.println(propiedades[a]);
		}
		
		//.getProperty
		System.out.println("***********************************************************");
		System.out.println(System.getProperty("os.name"));
		System.out.println(System.getProperty("os.version"));
		System.out.println(System.getProperty("os.arch"));
		System.out.println(System.getProperty("java.version"));
		System.out.println(System.getProperty("user.country"));
		System.out.println(System.getProperty("user.name"));
		System.out.println(System.getProperty("user.home"));
		
		// .getenv()
		System.out.println(System.getenv());
		System.out.println("***********************************************************");
		String[] propiedades2=System.getenv().toString().split(", ");
		for(int a=0;a<propiedades2.length;a++) {
			System.out.println(propiedades2[a]);
		}
		System.out.println("***********************************************************");
		System.out.println(System.getenv("USER"));
		
	}

}
