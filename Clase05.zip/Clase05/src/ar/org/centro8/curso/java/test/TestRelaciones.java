package ar.org.centro8.curso.java.test;

import java.util.List;

import ar.org.centro8.curso.java.entities.ClienteEmpresa;
import ar.org.centro8.curso.java.entities.ClientePersona;
import ar.org.centro8.curso.java.entities.Cuenta;

public class TestRelaciones {
	public static void main(String[] args) {
		
		System.out.println("-- cuenta1 --");
		Cuenta cuenta1 = new Cuenta(1,"arg$");
		cuenta1.depositar(80000);
		cuenta1.depositar(120000);
		cuenta1.debitar(32000);
		System.out.println(cuenta1);
		
		System.out.println("-- cliente1 --");
		ClientePersona cliente1 = new ClientePersona(1,"Juan Perez",38,2);
		cliente1.getCuenta().depositar(23000);
		
		Cuenta cuentaCliente=cliente1.getCuenta();
		cuentaCliente.depositar(40000);
		
		System.out.println(cliente1);
		
		System.out.println("-- clienteAna y clientePablo --");
		ClientePersona clienteAna=new ClientePersona(2,"Ana",26, new Cuenta(3,"args"));
		clienteAna.getCuenta().depositar(150000);
		
		ClientePersona clientePablo=new ClientePersona(3,"Pablo",26,clienteAna.getCuenta());
		clientePablo.getCuenta().debitar(60000);

		System.out.println(clienteAna);
		System.out.println(clientePablo);
		
		System.out.println("-- clienteEmpresa1 --");
		ClienteEmpresa clienteEmpresa1 = new ClienteEmpresa(1,"Todo Limpio srl","Lima 222");
		List<Cuenta>cuentas=clienteEmpresa1.getCuentas();
		cuentas.add(new Cuenta(10,"arg$"));						// 0
		cuentas.add(new Cuenta(11,"reales"));					// 1
		cuentas.add(new Cuenta(12,"U$D"));						// 2
		cuentas.get(0).depositar(56000);
		cuentas.get(0).depositar(39000);
		cuentas.get(0).debitar(11000);
		cuentas.get(1).depositar(36000);
		cuentas.get(2).depositar(15000);
		System.out.println(clienteEmpresa1);
		
		
		
		
		
	}
}
