package ar.org.centro8.curso.java.entities;

public class Empleado {
	private int nroLegajo;
	private String nombre;
	
	public Empleado(int nroLegajo, String nombre) {
		super();
		this.nroLegajo = nroLegajo;
		this.nombre = nombre;
	}
	
	@Override
	public String toString() {
		return "Empleado [nroLegajo=" + nroLegajo + ", nombre=" + nombre + "]";
	}
	
	public synchronized void usarAuto(Auto auto) {
		System.out.println(nombre+" usando: "+auto);
		try { Thread.sleep(5000); } catch(Exception e) {}
		System.out.println(nombre+" termino de usar: "+auto);
	}
	
	public int getNroLegajo() {
		return nroLegajo;
	}
	
	public String getNombre() {
		return nombre;
	}

}
