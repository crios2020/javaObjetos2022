package test;

import entities.Persona;
import enums.EstadoCivil;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Parameter;

public class TestApiReflect {
    public static void main(String[] args) {
        //api reflect
        Object o=new Persona("Juan", "Perez", 38, EstadoCivil.UNIONCIVIL);
        
        //Objeto Class
        System.out.println("-- Class --");
        System.out.println(o.getClass().getName());
        System.out.println(o.getClass().getSimpleName());
        System.out.println(o.getClass().getSuperclass().getName());
        
        //Objetos Fields (Atributos)
        System.out.println("-- Atributos privados--");
        Field[] campos=o.getClass().getDeclaredFields();
        for(Field f:campos) System.out.println(f.getName()+" "+f.getType().getName());
        
        System.out.println("-- Atributos publicos--");
        campos=o.getClass().getFields();
        for(Field f:campos) System.out.println(f.getName()+" "+f.getType().getName());
        
        //Objetos Methods (Métodos)
        System.out.println("-- Metodos --");
        Method[] metodos=o.getClass().getDeclaredMethods();
        for(Method m:metodos) {
            System.out.println("nombre: "+m.getName()+" devuelve: "+m.getGenericReturnType().getTypeName());
            System.out.println("\tParametros:");
            for(Parameter p:m.getParameters()){
                System.out.println("\t\t"+p.getName()+" "+p.getParameterizedType().getTypeName());
            }
        }
        
        System.out.println("-- Metodos Heredados--");
        metodos=o.getClass().getMethods();
        for(Method m:metodos) {
            System.out.println("nombre: "+m.getName()+" devuelve: "+m.getGenericReturnType().getTypeName());
            System.out.println("\tParametros:");
            for(Parameter p:m.getParameters()){
                System.out.println("\t\t"+p.getName()+" "+p.getParameterizedType().getTypeName());
            }
        }
       
        // getConstructors
        System.out.println("-- Constructores --");
        Constructor[] constructores=o.getClass().getConstructors();
        for(Constructor c:constructores){
            System.out.println("nombre: "+c.getName());
            System.out.println("\tParametros:");
            for(Parameter p:c.getParameters()){
                System.out.println("\t\t"+p.getName()+" "+p.getParameterizedType().getTypeName());
            }
        }

        //invoke
        
        
    }
}
