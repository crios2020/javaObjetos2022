package entities;

import enums.EstadoCivil;

public class Persona implements Comparable<Persona>{
    private String nombre;
    private String apellido;
    private int edad;
    private EstadoCivil estadoCivil;

    public Persona(String nombre, String apellido, int edad, EstadoCivil estadoCivil) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.estadoCivil = estadoCivil;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellido=" + apellido + ", edad=" + edad + ", estadoCivil=" + estadoCivil + '}';
    }

    @Override
    public int compareTo(Persona para) {
        String thisPersona=this.getNombre()+","+this.getApellido()+","+this.getEdad()+","+this.getEstadoCivil();
        String paraPersona=para.getNombre()+","+para.getApellido()+","+para.getEdad()+","+para.getEstadoCivil();
        return thisPersona.toLowerCase().compareTo(paraPersona.toLowerCase());
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public EstadoCivil getEstadoCivil() {
        return estadoCivil;
    }

    public void setEstadoCivil(EstadoCivil estadoCivil) {
        this.estadoCivil = estadoCivil;
    }

}
