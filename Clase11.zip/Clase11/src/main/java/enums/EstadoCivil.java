package enums;

public enum EstadoCivil {
    //Los enums JDK 5 o sup
    SOLTERO,
    CASADO,
    VIUDO,
    DIVORCIADO,
    UNIONCIVIL
}
