package test;

import entities.Persona;
import enums.EstadoCivil;

public class TestEnum {
    public static void main(String[] args) {
        Persona persona=new Persona("Ana", "Gallo", 38, EstadoCivil.SOLTERO);
        System.out.println(persona);

    }
}
