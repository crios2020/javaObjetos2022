package ar.com.eduit.curso.java.test;
public class TestMaven {
    public static void main(String[] args) {
        System.out.println("Hola Mundo Maven!");
        System.out.println("Versión de JDK: " + System.getProperty("java.version"));
    }
}
