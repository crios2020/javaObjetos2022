package ar.com.eduit.curso.java.repositories.jdbc;

import java.sql.Connection;

public class AlumnoRepository {
	private Connection conn;

	public AlumnoRepository(Connection conn) {
		this.conn = conn;
	}
	
}
