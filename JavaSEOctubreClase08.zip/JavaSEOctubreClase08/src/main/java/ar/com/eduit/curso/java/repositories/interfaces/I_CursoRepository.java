package ar.com.eduit.curso.java.repositories.interfaces;

import java.util.List;

import ar.com.eduit.curso.java.entities.Curso;

public interface I_CursoRepository {
	void save(Curso curso);
	void remove(Curso curso);
	void update(Curso curso);
	Curso getById(int id);
	List<Curso> getAll();
	List<Curso> getLikeTitulo(String titulo);
	
}
