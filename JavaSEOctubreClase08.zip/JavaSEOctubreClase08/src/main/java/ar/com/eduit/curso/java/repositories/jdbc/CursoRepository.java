package ar.com.eduit.curso.java.repositories.jdbc;

import java.sql.Connection;

public class CursoRepository {
	private Connection conn;

	public CursoRepository(Connection conn) {
		this.conn = conn;
	}
	
	
}
