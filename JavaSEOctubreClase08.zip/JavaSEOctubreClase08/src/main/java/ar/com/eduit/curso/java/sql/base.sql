-- Código DDL que arma la base de datos
select version();
drop database if exists colegio;
create database colegio;
use colegio;

drop table if exists alumnos;
drop table if exists colegio;

create table cursos(
	id int auto_increment primary key,
    titulo varchar(20) not null,
    profesor varchar(20) not null,
    dia enum('LUNES','MARTES','MIERCOLES','JUEVES','VIERNES'),
    turno enum('MAÑANA','TARDE','NOCHE')
);

create table alumnos(
	id int auto_increment primary key,
    nombre varchar(20) not null,
    apellido varchar(20) not null,
    edad int not null,
    idCurso int not null
);

alter table alumnos
	add constraint FK_Alumnos_Cursos
    foreign key(idCurso)
    references cursos(id);
