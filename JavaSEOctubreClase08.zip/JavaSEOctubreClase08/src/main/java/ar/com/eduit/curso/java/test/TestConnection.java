package ar.com.eduit.curso.java.test;

import java.sql.ResultSet;
import java.time.LocalTime;

import ar.com.eduit.curso.java.connectors.Connector;

public class TestConnection {

	public static void main(String[] args) {
		tiempo();
		try (ResultSet rs=Connector
				.getConnection()
				.createStatement()
				.executeQuery("select version()"))
		{
			if(rs.next()) System.out.println(rs.getString(1));
		} catch (Exception e) {
			System.out.println(e);
		}
		tiempo();
	}
	public static void tiempo() {
		System.out.println(LocalTime.now());
	}
}
