package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;

public class TestStatic {
	public static void main(String[] args) {
		Auto.acelerar();
		System.out.println("-- auto1 --");
		Auto auto1=new Auto("Renault","Kangoo","Bordo");
		Auto.acelerar();
		auto1.acelerar();
		auto1.acelerar();
		auto1.frenar();
		System.out.println(auto1+" "+Auto.getVelocidad());
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto("Honda","City","Blanco");
		auto2.acelerar();
		System.out.println(auto2+" "+auto2.getVelocidad());
		System.out.println(auto1+" "+auto1.getVelocidad());
	}
}
