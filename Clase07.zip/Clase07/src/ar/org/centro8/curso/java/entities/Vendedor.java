package ar.org.centro8.curso.java.entities;

public class Vendedor extends Persona{
	private int nroLegajo;
	private float sueldoBasico;
	
	public Vendedor(String nombre, int edad, Direccion direccion, int nroLegajo, float sueldoBasico) {
		super(nombre, edad, direccion); //llama al constructor de la clase padre
		this.nroLegajo = nroLegajo;
		this.sueldoBasico = sueldoBasico;
	}

	@Override
	public void saludar() {
		System.out.println("Hola soy un vendedor!");
	}

	@Override
	public String toString() {
		return "Vendedor [nroLegajo=" + nroLegajo + ", sueldoBasico=" + sueldoBasico + ", "
				+ super.toString() + "]";
	}

	public int getNroLegajo() {
		return nroLegajo;
	}

	public float getSueldoBasico() {
		return sueldoBasico;
	}

}
