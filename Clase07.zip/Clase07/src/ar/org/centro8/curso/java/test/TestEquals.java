package ar.org.centro8.curso.java.test;

import java.util.Scanner;

public class TestEquals {
	public static void main(String[] args) {
		System.out.println("Ingrese usario (root):");
		String user=new Scanner(System.in).nextLine();
		System.out.println(user=="root");
		System.out.println(user.equals("root"));
	}
}
