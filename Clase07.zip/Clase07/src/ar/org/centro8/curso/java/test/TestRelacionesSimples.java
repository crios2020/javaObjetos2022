package ar.org.centro8.curso.java.test;

import ar.org.centro8.curso.java.entities.Auto;
import ar.org.centro8.curso.java.entities.Empleado;

public class TestRelacionesSimples {
	public static void main(String[] args) {
		System.out.println("-- auto1 --");
		Auto auto1=new Auto("Peugeot","208","Blanco");
		System.out.println(auto1);
		
		System.out.println("-- auto2 --");
		Auto auto2=new Auto("VW","GOL","Blanco");
		System.out.println(auto2);
		
		System.out.println("-- empleado1 --");
		Empleado empleado1=new Empleado(1,"Laura");
		System.out.println(empleado1);
		
		System.out.println("-- empleado2 --");
		Empleado empleado2=new Empleado(2,"Eliana");
		System.out.println(empleado2);
		
		empleado1.usarAuto(auto2);
		empleado1.usarAuto(auto1);
		empleado2.usarAuto(auto2);
		empleado1.usarAuto(auto2);
		
	}
}
