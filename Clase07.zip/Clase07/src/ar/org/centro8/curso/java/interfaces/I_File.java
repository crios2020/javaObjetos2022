package ar.org.centro8.curso.java.interfaces;

public interface I_File {
	
	/*
	 * Interfaces en Java
	 * 
	 * - No tiene constructores ni atributos de instancias.
	 * - Solo tiene métodos abstractos y constantes o atributos de clase(static).
	 * - Todos los miembros de una clase son publicos.
	 * - La javaDOC es heredada
	 * - Una clase puede implementar muchas interfaces.
	 * 
	 */
	
	
	/**
	 * Este método escribe en el archivo
	 * @param text
	 */
	void setText(String text);
	void print();
	
	// Métodos default java8
	default void info() {
		System.out.println("Interface I_File");
	}

}
