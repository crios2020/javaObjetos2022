package ar.org.centro8.curso.java.app;

public class App {
	public static void main(String[] args) {
		System.out.println("***************************************************");
		System.out.println("         SISTEMA DE GESTIÓN              ");
		System.out.println("***************************************************");
	}
}
