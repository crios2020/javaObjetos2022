package org.centro8.curso.java.test;

import org.centro8.curso.java.connectors.Connector;
import org.centro8.curso.java.entities.Curso;
import org.centro8.curso.java.enums.Dia;
import org.centro8.curso.java.enums.Turno;
import org.centro8.curso.java.repositories.interfaces.I_CursoRepository;
import org.centro8.curso.java.repositories.jdbc.CursoRepository;

public class TestRepository {
    public static void main(String[] args) {
        I_CursoRepository cr=new CursoRepository(new Connector().getConnection());
        Curso curso=new Curso("Cocina","Mendez",Dia.JUEVES,Turno.NOCHE);
        cr.save(curso);
        System.out.println(curso);
        
        cr.save(new Curso("Jardineria","Segovia",Dia.LUNES,Turno.MAÑANA));
        
    }
}
